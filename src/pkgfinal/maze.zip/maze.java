/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;

public class maze extends Application {

    private static final Stage stage = new Stage();
    private static final Group playerGroup = new Group();
    private static int level = 0;
    private static Path maze = null;
    private static final ArrayList<Shape> enemies = new ArrayList<Shape>();

    @Override
    public void start(Stage mainStage) {

        GridPane gridpane = new GridPane();
        gridpane.setPadding(new Insets(50));
        gridpane.setAlignment(Pos.CENTER);
        Scene scene = new Scene(gridpane);
        
        Pane pane = new Pane();
        pane.setMinSize(500, 500);
        gridpane.getChildren().add(pane);

        Circle player = new Circle(10, Color.RED);
        playerGroup.getChildren().add(player);

        // setup keyboard functionality
        scene.setOnKeyPressed(e
                -> {
            if (pane.getChildren().contains(playerGroup) && maze != null) {
                // if the player is added to the pane and the maze is loaded
                double oldX = playerGroup.getLayoutX();
                double oldY = playerGroup.getLayoutY();
                double newX;
                double newY;

                switch (e.getCode()) {
                    case W:
                    case UP:
                        newX = playerGroup.getLayoutX();
                        newY = playerGroup.getLayoutY() - 10;
                        break;
                    case RIGHT:
                    case D:
                        newX = playerGroup.getLayoutX() + 10;
                        newY = playerGroup.getLayoutY();
                        break;
                    case DOWN:
                    case S:
                        newX = playerGroup.getLayoutX();
                        newY = playerGroup.getLayoutY() + 10;
                        break;
                    case LEFT:
                    case A:
                        newX = playerGroup.getLayoutX() - 10;
                        newY = playerGroup.getLayoutY();
                        break;
                    default:
                        return; // do nothing for other key strokes
                }

                if (newX > 0 && newY > 0 && newX < 500 && newY < 500) {
                    // if new coordinates are within maze
                    playerGroup.setLayoutX(newX);
                    playerGroup.setLayoutY(newY);

                    if (!Shape.intersect(player, maze).getBoundsInLocal().isEmpty()) {
                        // player is running into maze set old coordinates back
                        // https://stackoverflow.com/a/22542251
                        playerGroup.setLayoutX(oldX);
                        playerGroup.setLayoutY(oldY);
                    }
                    
                    for (Shape enemy: enemies) {
                        // iterate over all of the enemies in the maze
                        if (!Shape.intersect(player, enemy).getBoundsInLocal().isEmpty()) {
                            // if the player is tocuhing an enemy
                            FailScreen(pane);
                            return; // quit method since player failed
                        }
                    }

                    if (newX > 450 && newY > 470) {
                        // player is at the end of the maze

                        if (level == 1) {
                            Level2(pane);
                        } else {
                            WinScreen(pane);
                        }
                    }
                }
            }
        });

        StartMenu(pane); // add start menu as the first screen
        stage.setTitle("Maze");
        stage.setScene(scene);
        stage.show();
    }

    //Method creates maze and player icon for level 1 using Path class.
    public static void Level1(Pane pane) {
        level = 1;
        Path path = new Path(new MoveTo());
        path.setStrokeWidth(10);
        path.setStroke(Color.BLACK);

        path.getElements().add(new LineTo(0, 150));
        path.getElements().add(new LineTo(50, 150));
        path.getElements().add(new MoveTo(0, 150));
        path.getElements().add(new LineTo(0, 400));
        path.getElements().add(new LineTo(50, 400));
        path.getElements().add(new MoveTo(0, 400));
        path.getElements().add(new LineTo(0, 500));
        path.getElements().add(new LineTo(250, 500));
        path.getElements().add(new LineTo(250, 400));
        path.getElements().add(new LineTo(300, 400));
        path.getElements().add(new LineTo(300, 350));
        path.getElements().add(new LineTo(350, 350));
        path.getElements().add(new MoveTo(300, 350));
        path.getElements().add(new LineTo(300, 300));
        path.getElements().add(new LineTo(350, 300));
        path.getElements().add(new MoveTo(300, 300));
        path.getElements().add(new LineTo(300, 250));
        path.getElements().add(new LineTo(50, 250));
        path.getElements().add(new LineTo(50, 200));
        path.getElements().add(new MoveTo(50, 250));
        path.getElements().add(new LineTo(50, 350));
        path.getElements().add(new LineTo(250, 350));
        path.getElements().add(new LineTo(250, 300));
        path.getElements().add(new LineTo(100, 300));
        path.getElements().add(new MoveTo(200, 350));
        path.getElements().add(new LineTo(200, 400));
        path.getElements().add(new MoveTo(100, 350));
        path.getElements().add(new LineTo(100, 450));
        path.getElements().add(new LineTo(50, 450));
        path.getElements().add(new MoveTo(100, 450));
        path.getElements().add(new LineTo(200, 450));
        path.getElements().add(new MoveTo(150, 450));
        path.getElements().add(new LineTo(150, 400));
        path.getElements().add(new MoveTo(250, 250));
        path.getElements().add(new LineTo(250, 200));
        path.getElements().add(new LineTo(450, 200));
        path.getElements().add(new MoveTo(350, 200));
        path.getElements().add(new LineTo(350, 250));
        path.getElements().add(new LineTo(400, 250));
        path.getElements().add(new LineTo(400, 350));
        path.getElements().add(new LineTo(450, 350));
        path.getElements().add(new LineTo(450, 450));
        path.getElements().add(new MoveTo(450, 400));
        path.getElements().add(new LineTo(350, 400));
        path.getElements().add(new LineTo(350, 450));
        path.getElements().add(new LineTo(300, 450));
        path.getElements().add(new MoveTo(205, 500));
        path.getElements().add(new LineTo(450, 500));
        path.getElements().add(new MoveTo(400, 500));
        path.getElements().add(new LineTo(400, 450));
        path.getElements().add(new MoveTo(50, 0));
        path.getElements().add(new LineTo(500, 0));
        path.getElements().add(new MoveTo(200, 0));
        path.getElements().add(new LineTo(200, 100));
        path.getElements().add(new MoveTo(200, 50));
        path.getElements().add(new LineTo(100, 50));
        path.getElements().add(new MoveTo(50, 50));
        path.getElements().add(new LineTo(50, 100));
        path.getElements().add(new LineTo(150, 100));
        path.getElements().add(new LineTo(150, 150));
        path.getElements().add(new MoveTo(100, 100));
        path.getElements().add(new LineTo(100, 200));
        path.getElements().add(new LineTo(200, 200));
        path.getElements().add(new LineTo(200, 150));
        path.getElements().add(new LineTo(250, 150));
        path.getElements().add(new LineTo(250, 50));
        path.getElements().add(new MoveTo(300, 200));
        path.getElements().add(new LineTo(300, 50));
        path.getElements().add(new MoveTo(350, 0));
        path.getElements().add(new LineTo(350, 150));
        path.getElements().add(new LineTo(450, 150));
        path.getElements().add(new MoveTo(500, 0));
        path.getElements().add(new LineTo(500, 500));
        path.getElements().add(new MoveTo(500, 100));
        path.getElements().add(new LineTo(400, 100));
        path.getElements().add(new LineTo(400, 50));
        path.getElements().add(new LineTo(450, 50));
        path.getElements().add(new MoveTo(500, 300));
        path.getElements().add(new LineTo(450, 300));
        path.getElements().add(new LineTo(450, 250));

        maze = path;
        pane.getChildren().clear();
        pane.getChildren().add(path);
        enemies.clear();
        // add enemies to array list
        AddPlayer(pane);
    }

    //Method creates maze and player icon for level 2 using Path class.
    public static void Level2(Pane pane) {
        level = 2;
        Path path = new Path(new MoveTo());
        path.setStrokeWidth(10);
        path.setStroke(Color.BLACK);

        path.getElements().add(new LineTo(0, 100));
        path.getElements().add(new LineTo(50, 100));
        path.getElements().add(new LineTo(50, 50));
        path.getElements().add(new MoveTo(50, 100));
        path.getElements().add(new LineTo(100, 100));
        path.getElements().add(new LineTo(100, 150));
        path.getElements().add(new LineTo(150, 150));
        path.getElements().add(new MoveTo(0, 100));
        path.getElements().add(new LineTo(0, 250));
        path.getElements().add(new LineTo(50, 250));
        path.getElements().add(new LineTo(50, 300));
        path.getElements().add(new LineTo(100, 300));
        path.getElements().add(new MoveTo(0, 250));
        path.getElements().add(new LineTo(0, 450));
        path.getElements().add(new LineTo(50, 450));
        path.getElements().add(new MoveTo(0, 450));
        path.getElements().add(new LineTo(0, 500));
        path.getElements().add(new LineTo(350, 500));
        path.getElements().add(new LineTo(350, 350));
        path.getElements().add(new LineTo(400, 350));
        path.getElements().add(new LineTo(400, 450));
        path.getElements().add(new LineTo(450, 450));
        path.getElements().add(new MoveTo(350, 450));
        path.getElements().add(new LineTo(100, 450));
        path.getElements().add(new LineTo(100, 350));
        path.getElements().add(new LineTo(50, 350));
        path.getElements().add(new LineTo(50, 400));
        path.getElements().add(new MoveTo(100, 350));
        path.getElements().add(new LineTo(150, 350));
        path.getElements().add(new LineTo(150, 250));
        path.getElements().add(new LineTo(100, 250));
        path.getElements().add(new LineTo(100, 200));
        path.getElements().add(new LineTo(50, 200));
        path.getElements().add(new LineTo(50, 150));
        path.getElements().add(new MoveTo(350, 500));
        path.getElements().add(new LineTo(450, 500));
        path.getElements().add(new MoveTo(500, 500));
        path.getElements().add(new LineTo(500, 400));
        path.getElements().add(new LineTo(450, 400));
        path.getElements().add(new MoveTo(500, 400));
        path.getElements().add(new LineTo(500, 350));
        path.getElements().add(new LineTo(450, 350));
        path.getElements().add(new MoveTo(500, 350));
        path.getElements().add(new LineTo(500, 100));
        path.getElements().add(new LineTo(450, 100));
        path.getElements().add(new LineTo(450, 200));
        path.getElements().add(new LineTo(350, 200));
        path.getElements().add(new LineTo(350, 250));
        path.getElements().add(new LineTo(400, 250));
        path.getElements().add(new MoveTo(450, 200));
        path.getElements().add(new LineTo(450, 300));
        path.getElements().add(new LineTo(300, 300));
        path.getElements().add(new LineTo(300, 400));
        path.getElements().add(new LineTo(250, 400));
        path.getElements().add(new MoveTo(500, 100));
        path.getElements().add(new LineTo(500, 0));
        path.getElements().add(new MoveTo(450, 50));
        path.getElements().add(new LineTo(400, 50));
        path.getElements().add(new LineTo(400, 150));
        path.getElements().add(new LineTo(300, 150));
        path.getElements().add(new LineTo(300, 250));
        path.getElements().add(new MoveTo(300, 150));
        path.getElements().add(new LineTo(200, 150));
        path.getElements().add(new MoveTo(250, 150));
        path.getElements().add(new LineTo(250, 350));
        path.getElements().add(new LineTo(200, 350));
        path.getElements().add(new LineTo(200, 400));
        path.getElements().add(new LineTo(150, 400));
        path.getElements().add(new MoveTo(150, 300));
        path.getElements().add(new LineTo(200, 300));
        path.getElements().add(new LineTo(200, 200));
        path.getElements().add(new LineTo(150, 200));
        path.getElements().add(new MoveTo(300, 150));
        path.getElements().add(new LineTo(300, 50));
        path.getElements().add(new MoveTo(500, 100));
        path.getElements().add(new LineTo(500, 0));
        path.getElements().add(new LineTo(350, 0));
        path.getElements().add(new LineTo(350, 100));
        path.getElements().add(new MoveTo(350, 0));
        path.getElements().add(new LineTo(200, 0));
        path.getElements().add(new LineTo(200, 100));
        path.getElements().add(new LineTo(250, 100));
        path.getElements().add(new LineTo(250, 50));
        path.getElements().add(new MoveTo(200, 100));
        path.getElements().add(new LineTo(150, 100));
        path.getElements().add(new LineTo(150, 50));
        path.getElements().add(new LineTo(100, 50));
        path.getElements().add(new MoveTo(200, 0));
        path.getElements().add(new LineTo(50, 0));

        maze = path;
        pane.getChildren().clear();
        pane.getChildren().add(path);
        enemies.clear();
        // add enemies to array list
        AddPlayer(pane);
    }

    public static void StartMenu(Pane pane) {
        level = 0;
        GridPane gridPane = new GridPane();
        Button start = new Button();
        Button quit = new Button();
        Button howTo = new Button();

        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setMinSize(500, 500);
        gridPane.setStyle("-fx-background-color: #2e8b57;");

        GridPane.setHalignment(start, HPos.CENTER);
        GridPane.setHalignment(quit, HPos.CENTER);
        GridPane.setHalignment(howTo, HPos.CENTER);

        start.setOnMousePressed(e -> Level1(pane));
        quit.setOnMousePressed(e -> Close());
        howTo.setOnMousePressed(e -> HowTo (pane));

        start.setText("START");
        quit.setText("QUIT");
        howTo.setText("HOW TO");
        gridPane.add(howTo, 0, 1);
        gridPane.add(quit, 0, 2);
        gridPane.add(start, 0, 3);

        gridPane.setGridLinesVisible(true);
        gridPane.getRowConstraints().setAll(new RowConstraints(25));

        maze = null;
        pane.getChildren().clear();
        pane.getChildren().add(gridPane);
    }
    
    public static void HowTo (Pane pane)
    {
    level = 0;
        GridPane gridPane = new GridPane();
        Button mainMenu = new Button();
        
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setMinSize(500, 500);
        gridPane.setStyle("-fx-background-color: #2e8b57;");
        
        GridPane.setHalignment(mainMenu, HPos.CENTER);
        mainMenu.setText("MAIN MENU");
        mainMenu.setOnMousePressed(e -> StartMenu(pane));
        
        gridPane.add(mainMenu, 0, 0);
        gridPane.setGridLinesVisible(true);
        gridPane.getRowConstraints().setAll(new RowConstraints(25));

        maze = null;
        pane.getChildren().clear();
        pane.getChildren().add(gridPane);
        
    }

    public static void FailScreen(Pane pane) {
        level = 0;
        GridPane gridPane = new GridPane();
        Button tryAgain = new Button();
        Button quit = new Button();
        Button mainMenu = new Button();

        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setMinSize(500, 500);
        gridPane.setStyle("-fx-background-color: #2e8b57;");

        GridPane.setHalignment(tryAgain, HPos.CENTER);
        GridPane.setHalignment(quit, HPos.CENTER);
        GridPane.setHalignment(mainMenu, HPos.CENTER);

        tryAgain.setText("TRY AGAIN");
        quit.setText("QUIT");
        mainMenu.setText("MAIN MENU");

        mainMenu.setOnMousePressed(e -> StartMenu(pane));
        quit.setOnMousePressed(e -> Close());
        tryAgain.setOnMousePressed(e -> {
            if (level == 1) {
                Level1(pane);
            } else if (level == 2) {
                Level2(pane);
            }
        });

        gridPane.add(tryAgain, 0, 1);
        gridPane.add(quit, 0, 2);
        gridPane.add(mainMenu, 0, 3);

        gridPane.setGridLinesVisible(true);
        gridPane.getRowConstraints().setAll(new RowConstraints(25));

        maze = null;
        pane.getChildren().clear();
        pane.getChildren().add(gridPane);
    }

    public static void WinScreen(Pane pane) {
        level = 0;
        GridPane gridPane = new GridPane();
        Button quit = new Button();
        Button mainMenu = new Button();
        Button replay = new Button();

        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setMinSize(500, 500);
        gridPane.setStyle("-fx-background-color: #2e8b57;");

        GridPane.setHalignment(quit, HPos.CENTER);
        GridPane.setHalignment(mainMenu, HPos.CENTER);
        GridPane.setHalignment(replay, HPos.CENTER);

        quit.setText("QUIT");
        mainMenu.setText("MAIN MENU");
        replay.setText("REPLAY");

        mainMenu.setOnMousePressed(e -> StartMenu(pane));
        replay.setOnMousePressed(e -> Level1(pane));
        quit.setOnMousePressed(e -> Close());

        gridPane.add(quit, 0, 1);
        gridPane.add(mainMenu, 0, 2);
        gridPane.add(replay, 0, 3);

        gridPane.setGridLinesVisible(true);
        gridPane.getRowConstraints().setAll(new RowConstraints(25));

        maze = null;
        pane.getChildren().clear();
        pane.getChildren().add(gridPane);
    }

    public static void Close() {
        stage.close();
    }

    public static void AddPlayer(Pane pane) {
        pane.getChildren().add(playerGroup);
        playerGroup.setLayoutX(25);
        playerGroup.setLayoutY(25);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
